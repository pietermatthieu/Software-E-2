﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yahtzee_5
{
    /*
        Hier gebeurt voorlopig niets mee
        Om 100% correct te zijn zou hier het huidig aantal worpen, maximum aantal worpen 
        en de score in opgeslaan moeten worden
        Kan je dus perfect eens proberen om zelf te implementeren
    */
    class ScoreboardModel
    {
    }
}
